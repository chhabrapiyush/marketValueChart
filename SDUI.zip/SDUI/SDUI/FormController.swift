//
//  FormController.swift
//  SDUI
//
//  Created by Piyush Chhabra on 4/16/25.
//


import SwiftUI
import Combine

/// FormController - Manages the loading and display of dynamic forms
class FormController: ObservableObject {
    private let networkManager = NetworkManager()
    private var cancellables = Set<AnyCancellable>()
    
    @Published var formViewModel: DynamicFormViewModel?
    @Published var isLoading = false
    @Published var error: Error?
    @Published var showingReviewScreen = false
    @Published var formSubmitted = false
    
    /// Load a form from a remote URL or from a local bundle
    func loadForm(from endpoint: String) {
        isLoading = true
        
        // First try to load from cache
        if let cachedForm = FormCache.shared.getForm(for: endpoint) {
            self.formViewModel = createViewModel(from: cachedForm)
            self.isLoading = false
            return
        }
        
        // Otherwise fetch from network
        networkManager.fetchForm(from: endpoint)
            .receive(on: DispatchQueue.main)
            .sink(
                receiveCompletion: { [weak self] completion in
                    self?.isLoading = false
                    
                    if case .failure(let error) = completion {
                        self?.error = error
                    }
                },
                receiveValue: { [weak self] formSpecification in
                    // Cache the received form
                    FormCache.shared.cacheForm(formSpecification, for: endpoint)
                    
                    // Create a view model with the specification
                    self?.formViewModel = self?.createViewModel(from: formSpecification)
                }
            )
            .store(in: &cancellables)
    }
    
    /// Load a form from a local JSON string (useful for testing)
    func loadFormFromJSON(_ jsonString: String) {
        isLoading = true
        
        guard let jsonData = jsonString.data(using: .utf8) else {
            self.error = NSError(domain: "FormError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid JSON string"])
            self.isLoading = false
            return
        }
        
        Just(jsonData)
            .decode(type: FormSpecification.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(
                receiveCompletion: { [weak self] completion in
                    self?.isLoading = false
                    
                    if case .failure(let error) = completion {
                        self?.error = error
                    }
                },
                receiveValue: { [weak self] formSpecification in
                    self?.formViewModel = self?.createViewModel(from: formSpecification)
                }
            )
            .store(in: &cancellables)
    }
    
    /// Create a view model from a form specification
    private func createViewModel(from specification: FormSpecification) -> DynamicFormViewModel {
        let viewModel = DynamicFormViewModel()
        viewModel.formSpecification = specification
        viewModel.initializeDefaultValues(for: specification)
        return viewModel
    }
    
    /// Handle form submission
    func submitForm() {
        guard let viewModel = formViewModel, let specification = viewModel.formSpecification else {
            return
        }
        
        isLoading = true
        
        // Prepare form data for submission
        let formData = viewModel.formValues
        
        // Get the endpoint and method from the form specification
        let endpoint = specification.actions.submit.endpoint
        let method = specification.actions.submit.method
        
        // Submit the form
        networkManager.submitForm(to: endpoint, method: method, data: formData)
            .receive(on: DispatchQueue.main)
            .sink(
                receiveCompletion: { [weak self] completion in
                    self?.isLoading = false
                    
                    if case .failure(let error) = completion {
                        self?.error = error
                    }
                },
                receiveValue: { [weak self] _ in
                    self?.formSubmitted = true
                }
            )
            .store(in: &cancellables)
    }
    
    /// Navigate to the review screen
    func showReviewScreen() {
        showingReviewScreen = true
    }
    
    /// Navigate back to the form from the review screen
    func editForm() {
        showingReviewScreen = false
    }
    
    /// Reset the form to its initial state
    func resetForm() {
        formViewModel = nil
        formSubmitted = false
        showingReviewScreen = false
        error = nil
    }
}

/// NetworkManager - Handles network requests for forms
class NetworkManager {
    /// Fetch a form specification from a remote endpoint
    func fetchForm(from endpoint: String) -> AnyPublisher<FormSpecification, Error> {
        guard let url = URL(string: endpoint) else {
            return Fail(error: NSError(domain: "FormError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"]))
                .eraseToAnyPublisher()
        }
        
        return URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data)
            .decode(type: FormSpecification.self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
    
    /// Submit form data to a remote endpoint
    func submitForm(to endpoint: String, method: String, data: [String: Any]) -> AnyPublisher<Void, Error> {
        guard let url = URL(string: endpoint) else {
            return Fail(error: NSError(domain: "FormError", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid URL"]))
                .eraseToAnyPublisher()
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            // Convert Swift dictionary to JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: data, options: [])
            request.httpBody = jsonData
        } catch {
            return Fail(error: error).eraseToAnyPublisher()
        }
        
        return URLSession.shared.dataTaskPublisher(for: request)
            .tryMap { output in
                // Check for successful status code
                guard let response = output.response as? HTTPURLResponse,
                      (200...299).contains(response.statusCode) else {
                    throw NSError(domain: "FormError", code: 2, userInfo: [NSLocalizedDescriptionKey: "Server error"])
                }
                
                return ()
            }
            .eraseToAnyPublisher()
    }
}

/// FormCache - Caches form specifications to reduce network requests
class FormCache {
    static let shared = FormCache()
    
    private var cache: [String: FormSpecification] = [:]
    
    private init() {}
    
    func cacheForm(_ form: FormSpecification, for key: String) {
        cache[key] = form
    }
    
    func getForm(for key: String) -> FormSpecification? {
        return cache[key]
    }
    
    func clearCache() {
        cache.removeAll()
    }
}

/// Main application form coordinator view
struct DynamicFormCoordinator: View {
    @StateObject private var formController = FormController()
    
    let formEndpoint: String
    
    var body: some View {
        ZStack {
            if formController.isLoading {
                ProgressView("Loading...")
            } else if formController.formSubmitted {
                // Success view after form submission
                FormSuccessView(onReset: {
                    formController.resetForm()
                })
            } else if let error = formController.error {
                // Error view if form loading or submission fails
                FormErrorView(error: error, onRetry: {
                    formController.loadForm(from: formEndpoint)
                })
            } else if formController.showingReviewScreen {
                // Review screen before final submission
                if let viewModel = formController.formViewModel, 
                   let specification = viewModel.formSpecification {
                    ReviewScreenView(
                        specification: specification,
                        formValues: viewModel.formValues,
                        onSubmit: {
                            formController.submitForm()
                        },
                        onEdit: {
                            formController.editForm()
                        }
                    )
                }
            } else if let viewModel = formController.formViewModel {
                // Main form view
                DynamicFormView(viewModel: viewModel)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarTrailing) {
                            if viewModel.currentSectionIndex == (viewModel.formSpecification?.sections.count ?? 0) - 1 {
                                Button("Review") {
                                    formController.showReviewScreen()
                                }
                            }
                        }
                    }
            } else {
                // Initial state - load the form
                Button("Load Form") {
                    formController.loadForm(from: formEndpoint)
                }
                .onAppear {
                    formController.loadForm(from: formEndpoint)
                }
            }
        }
        .navigationTitle("ACH Transfer")
    }
}

/// Success view shown after form submission
struct FormSuccessView: View {
    let onReset: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "checkmark.circle.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(.green)
            
            Text("Submission Successful")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Your ACH transfer has been submitted successfully.")
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            Button("Start New Transfer") {
                onReset()
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)
            .padding(.top, 20)
        }
        .padding()
    }
}

/// Error view shown when form loading or submission fails
struct FormErrorView: View {
    let error: Error
    let onRetry: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "exclamationmark.triangle.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(.orange)
            
            Text("Something Went Wrong")
                .font(.title)
                .fontWeight(.bold)
            
            Text(error.localizedDescription)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            Button("Retry") {
                onRetry()
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)
            .padding(.top, 20)
        }
        .padding()
    }
}

/// Example usage in a SwiftUI app
struct ACHTransferApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                DynamicFormCoordinator(formEndpoint: "https://api.example.com/forms/ach-transfer")
            }
        }
    }
}