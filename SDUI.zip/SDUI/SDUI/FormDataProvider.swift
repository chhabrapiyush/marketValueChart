//
//  FormDataProvider.swift
//  SDUI
//
//  Created by Piyush Chhabra on 4/16/25.
//


import SwiftUI
import Combine

// MARK: - Data Providers

/// Protocol for form data providers
protocol FormDataProvider {
    /// Get accounts for the authenticated user
    func getUserAccounts() -> AnyPublisher<[BankAccount], Error>
    
    /// Get saved recipients for the authenticated user
    func getSavedRecipients() -> AnyPublisher<[TransferRecipient], Error>
    
    /// Validate a routing number
    func validateRoutingNumber(_ routingNumber: String) -> AnyPublisher<Bool, Error>
}

/// Models for form data

/// Bank account model
struct BankAccount: Identifiable, Equatable, Decodable {
    let id: String
    let accountNumber: String
    let accountName: String
    let accountType: AccountType
    let balance: Double
    
    enum AccountType: String, CaseIterable, Decodable {
        case checking = "Checking"
        case savings = "Savings"
        case moneyMarket = "Money Market"
        case lineOfCredit = "Line of Credit"
    }
    
    var accountNameWithMaskedNumber: String {
        let lastFour = String(accountNumber.suffix(4))
        return "\(accountName) (\(accountType.rawValue)) •••• \(lastFour)"
    }
}

/// Transfer recipient model
struct TransferRecipient: Identifiable, Equatable, Decodable {
    let id: String
    let name: String
    let nickname: String?
    let routingNumber: String
    let accountNumber: String
    let accountType: BankAccount.AccountType
    
    var recipientNameWithMaskedAccount: String {
        let lastFour = String(accountNumber.suffix(4))
        return "\(name) •••• \(lastFour)"
    }
}

/// Live implementation of the FormDataProvider
class FormDataService: FormDataProvider {
    private let networkClient: NetworkClient
    
    init(networkClient: NetworkClient = URLSessionNetworkClient()) {
        self.networkClient = networkClient
    }
    
    func getUserAccounts() -> AnyPublisher<[BankAccount], Error> {
        return networkClient.request(.get, endpoint: "/api/accounts")
            .decode(type: [BankAccount].self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
    
    func getSavedRecipients() -> AnyPublisher<[TransferRecipient], Error> {
        return networkClient.request(.get, endpoint: "/api/recipients")
            .decode(type: [TransferRecipient].self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
    
    func validateRoutingNumber(_ routingNumber: String) -> AnyPublisher<Bool, Error> {
        return networkClient.request(.get, endpoint: "/api/validate/routing/\(routingNumber)")
            .map { data -> Bool in
                do {
                    if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                       let isValid = json["isValid"] as? Bool {
                        return isValid
                    }
                    return false
                } catch {
                    return false
                }
            }
            .eraseToAnyPublisher()
    }
}

/// Mock implementation for testing and previews
class MockFormDataService: FormDataProvider {
    func getUserAccounts() -> AnyPublisher<[BankAccount], Error> {
        let accounts = [
            BankAccount(
                id: "acc1",
                accountNumber: "123456789",
                accountName: "Primary Checking",
                accountType: .checking,
                balance: 4578.92
            ),
            BankAccount(
                id: "acc2",
                accountNumber: "987654321",
                accountName: "High Yield Savings",
                accountType: .savings,
                balance: 25789.14
            ),
            BankAccount(
                id: "acc3",
                accountNumber: "456123789",
                accountName: "Emergency Fund",
                accountType: .moneyMarket,
                balance: 10000.00
            )
        ]
        
        return Just(accounts)
            .setFailureType(to: Error.self)
            .eraseToAnyPublisher()
    }
    
    func getSavedRecipients() -> AnyPublisher<[TransferRecipient], Error> {
        let recipients = [
            TransferRecipient(
                id: "rec1",
                name: "John Smith",
                nickname: "John's Checking",
                routingNumber: "123456789",
                accountNumber: "987654321",
                accountType: .checking
            ),
            TransferRecipient(
                id: "rec2",
                name: "Jane Doe",
                nickname: "Jane's Rent Account",
                routingNumber: "987654321",
                accountNumber: "123456789",
                accountType: .checking
            ),
            TransferRecipient(
                id: "rec3",
                name: "Acme Utilities",
                nickname: "Utility Bill",
                routingNumber: "456789123",
                accountNumber: "789123456",
                accountType: .checking
            )
        ]
        
        return Just(recipients)
            .setFailureType(to: Error.self)
            .eraseToAnyPublisher()
    }
    
    func validateRoutingNumber(_ routingNumber: String) -> AnyPublisher<Bool, Error> {
        // Simple validation - ABA routing numbers need to be 9 digits
        // This is a simplified mock implementation
        let isValid = routingNumber.count == 9 && Int(routingNumber) != nil
        return Just(isValid)
            .setFailureType(to: Error.self)
            .eraseToAnyPublisher()
    }
}

// MARK: - Network Client

/// HTTP Method enum
enum HTTPMethod: String {
    case get = "GET"
    case post = "POST"
    case put = "PUT"
    case delete = "DELETE"
}

/// Network client protocol
protocol NetworkClient {
    func request(_ method: HTTPMethod, endpoint: String, body: Data?) -> AnyPublisher<Data, Error>
}

extension NetworkClient {
    func request(_ method: HTTPMethod, endpoint: String) -> AnyPublisher<Data, Error> {
        return request(method, endpoint: endpoint, body: nil)
    }
}

/// URLSession-based network client
class URLSessionNetworkClient: NetworkClient {
    private let baseURL: URL
    private let session: URLSession
    
    init(baseURL: URL = URL(string: "https://api.example.com")!, session: URLSession = .shared) {
        self.baseURL = baseURL
        self.session = session
    }
    
    func request(_ method: HTTPMethod, endpoint: String, body: Data? = nil) -> AnyPublisher<Data, Error> {
        guard let url = URL(string: endpoint, relativeTo: baseURL) else {
            return Fail(error: URLError(.badURL))
                .eraseToAnyPublisher()
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        
        if let body = body {
            request.httpBody = body
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        
        // Add auth token if available
        if let token = AuthManager.shared.token {
            request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        return session.dataTaskPublisher(for: request)
            .tryMap { data, response in
                guard let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode) else {
                    throw URLError(.badServerResponse)
                }
                return data
            }
            .eraseToAnyPublisher()
    }
}

// MARK: - Auth Manager

/// Simple auth manager singleton
class AuthManager {
    static let shared = AuthManager()
    
    var token: String?
    
    private init() {}
    
    func setToken(_ token: String) {
        self.token = token
    }
    
    func clearToken() {
        self.token = nil
    }
    
    var isAuthenticated: Bool {
        return token != nil
    }
}

// MARK: - Dynamic Data Sources

/// Integrates data providers with the form system
class DynamicDataSourceManager {
    private let dataProvider: FormDataProvider
    
    private var userAccounts: [BankAccount] = []
    private var savedRecipients: [TransferRecipient] = []
    
    private var cancellables = Set<AnyCancellable>()
    
    init(dataProvider: FormDataProvider = FormDataService()) {
        self.dataProvider = dataProvider
    }
    
    /// Load all data sources
    func loadData() {
        loadUserAccounts()
        loadSavedRecipients()
    }
    
    private func loadUserAccounts() {
        dataProvider.getUserAccounts()
            .receive(on: DispatchQueue.main)
            .sink(
                receiveCompletion: { completion in
                    if case .failure(let error) = completion {
                        print("Error loading accounts: \(error)")
                    }
                },
                receiveValue: { [weak self] accounts in
                    self?.userAccounts = accounts
                }
            )
            .store(in: &cancellables)
    }
    
    private func loadSavedRecipients() {
        dataProvider.getSavedRecipients()
            .receive(on: DispatchQueue.main)
            .sink(
                receiveCompletion: { completion in
                    if case .failure(let error) = completion {
                        print("Error loading recipients: \(error)")
                    }
                },
                receiveValue: { [weak self] recipients in
                    self?.savedRecipients = recipients
                }
            )
            .store(in: &cancellables)
    }
    
    /// Get data for a specific source ID
    func getData(for sourceId: String) -> [Any] {
        switch sourceId {
        case "userAccounts":
            return userAccounts
        case "savedRecipients":
            return savedRecipients
        default:
            return []
        }
    }
    
    /// Get display string for an item based on display key
    func getDisplayString(for item: Any, using displayKey: String) -> String {
        if let account = item as? BankAccount {
            switch displayKey {
            case "accountNameWithMaskedNumber":
                return account.accountNameWithMaskedNumber
            default:
                return "\(account.accountName)"
            }
        } else if let recipient = item as? TransferRecipient {
            switch displayKey {
            case "recipientNameWithMaskedAccount":
                return recipient.recipientNameWithMaskedAccount
            default:
                return recipient.name
            }
        }
        
        return "\(item)"
    }
    
    /// Find an item by ID in a data source
    func findItem(withId id: String, in sourceId: String) -> Any? {
        switch sourceId {
        case "userAccounts":
            return userAccounts.first { $0.id == id }
        case "savedRecipients":
            return savedRecipients.first { $0.id == id }
        default:
            return nil
        }
    }
}

// MARK: - Form Extensions for Data Providers

extension DynamicFormViewModel {
    /// Initialize data sources for the form
    func initializeDataSources(with dataSourceManager: DynamicDataSourceManager) {
        // Make data sources available to the form
        self.dataSourceManager = dataSourceManager
        
        // Load the data
        dataSourceManager.loadData()
    }
    
    /// Get options for a picker from a data source
    func getOptionsForPicker(element: FormElement) -> [PickerOption] {
        guard let dataSource = element.dataSource,
              let dataSourceManager = self.dataSourceManager else {
            return []
        }
        
        let items = dataSourceManager.getData(for: dataSource)
        let displayKey = element.displayKey ?? "id"
        
        return items.compactMap { item -> PickerOption? in
            if let identifiable = item as? AnyHashable {
                let displayString = dataSourceManager.getDisplayString(for: item, using: displayKey)
                return PickerOption(id: "\(identifiable)", label: displayString)
            }
            return nil
        }
    }
    
    // Add property to store the data source manager
    private var dataSourceManager: DynamicDataSourceManager? {
        get {
            objc_getAssociatedObject(self, &AssociatedKeys.dataSourceManager) as? DynamicDataSourceManager
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.dataSourceManager, newValue, .OBJC_ASSOCIATION_RETAIN)
        }
    }
    
    private struct AssociatedKeys {
        static var dataSourceManager = "dataSourceManager"
    }
}

/// Picker option model
struct PickerOption: Identifiable, Hashable {
    let id: String
    let label: String
}

// Required import for associated objects
import ObjectiveC
