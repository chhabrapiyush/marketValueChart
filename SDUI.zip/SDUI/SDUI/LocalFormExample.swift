//
//  LocalFormExample.swift
//  SDUI
//
//  Created by Piyush Chhabra on 4/16/25.
//


import SwiftUI

/// Example of loading a form from a local JSON string
struct LocalFormExample: View {
    @StateObject private var formController = FormController()
    
    // This would normally be loaded from a file or network
    let jsonFormString = """
    {
      "formName": "ACHTransfer",
      "version": "1.0",
      "sections": [
        {
          "id": "transferDetails",
          "title": "Transfer Details",
          "elements": [
            {
              "id": "transferType",
              "type": "segmentedControl",
              "label": "Transfer Type",
              "required": true,
              "options": [
                {"id": "oneTime", "label": "One-Time Transfer"},
                {"id": "recurring", "label": "Recurring Transfer"}
              ],
              "defaultValue": "oneTime",
              "dependentFields": {
                "recurring": ["frequency", "startDate", "endDate"]
              }
            },
            {
              "id": "fromAccount",
              "type": "picker",
              "label": "From Account",
              "required": true,
              "dataSource": "userAccounts",
              "displayKey": "accountNameWithMaskedNumber"
            },
            {
              "id": "amount",
              "type": "textField",
              "label": "Amount",
              "required": true,
              "keyboardType": "decimalPad",
              "accessoryView": "currencySymbol",
              "validation": {
                "regex": "^\\\\d+(\\\\.\\\\d{1,2})?$",
                "minValue": 0.01,
                "maxValue": 25000,
                "errorMessage": "Please enter a valid amount between $0.01 and $25,000"
              }
            }
          ]
        },
        {
          "id": "recipientSection",
          "title": "Recipient Information",
          "elements": [
            {
              "id": "recipientType",
              "type": "segmentedControl",
              "label": "Recipient Type",
              "required": true,
              "options": [
                {"id": "existing", "label": "Existing Recipient"},
                {"id": "new", "label": "New Recipient"}
              ],
              "defaultValue": "existing",
              "dependentFields": {
                "existing": ["recipientAccount"],
                "new": ["recipientName", "routingNumber", "accountNumber", "accountType"]
              }
            },
            {
              "id": "recipientAccount",
              "type": "picker",
              "label": "Select Recipient",
              "required": true,
              "visibleWhen": {"field": "recipientType", "equals": "existing"},
              "dataSource": "savedRecipients"
            },
            {
              "id": "recipientName",
              "type": "textField",
              "label": "Recipient Name",
              "required": true,
              "visibleWhen": {"field": "recipientType", "equals": "new"},
              "keyboardType": "default",
              "validation": {
                "regex": "^[a-zA-Z0-9 ,.'-]{2,100}$",
                "errorMessage": "Please enter a valid recipient name (2-100 characters)"
              }
            }
          ]
        },
        {
          "id": "confirmationSection",
          "title": "Confirm Transfer",
          "elements": [
            {
              "id": "termsAgreement",
              "type": "checkbox",
              "label": "I agree to the Terms and Conditions of ACH Transfers",
              "required": true,
              "validation": {
                "rule": "isTrue",
                "errorMessage": "You must agree to the terms to proceed"
              }
            }
          ]
        }
      ],
      "navigationFlow": {
        "steps": [
          {
            "id": "transferDetails",
            "nextStep": "recipientSection",
            "validationTrigger": "onContinue"
          },
          {
            "id": "recipientSection",
            "nextStep": "confirmationSection",
            "validationTrigger": "onContinue"
          },
          {
            "id": "confirmationSection",
            "nextStep": "review",
            "validationTrigger": "onContinue"
          }
        ]
      },
      "reviewScreen": {
        "id": "review",
        "title": "Review Transfer",
        "showAllFields": true,
        "highlightFields": ["fromAccount", "amount", "recipientName"]
      },
      "actions": {
        "submit": {
          "endpoint": "/api/transfers/ach",
          "method": "POST",
          "requiresAuthentication": true,
          "successMessage": "Transfer submitted successfully"
        },
        "save": {
          "endpoint": "/api/transfers/draft",
          "method": "POST",
          "requiresAuthentication": true,
          "successMessage": "Draft saved successfully"
        },
        "cancel": {
          "confirmationRequired": true,
          "confirmationMessage": "Are you sure you want to cancel this transfer?",
          "navigateTo": "homeScreen"
        }
      },
      "accessibility": {
        "voiceOverLabels": {
          "amount": "Transfer amount in dollars",
          "routingNumber": "Bank routing number, 9 digits",
          "accountNumber": "Bank account number"
        },
        "dynamicTypeSupport": true,
        "reduceMotion": true
      }
    }
    """
    
    var body: some View {
        ZStack {
            if formController.isLoading {
                ProgressView("Loading form...")
            } else if let error = formController.error {
                Text("Error loading form: \(error.localizedDescription)")
                    .foregroundColor(.red)
                    .padding()
            } else if let viewModel = formController.formViewModel {
                DynamicFormView(viewModel: viewModel)
            } else {
                VStack {
                    Text("Dynamic ACH Transfer Form")
                        .font(.title)
                        .padding()
                    
                    Button("Load Form") {
                        formController.loadFormFromJSON(jsonFormString)
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                }
            }
        }
        .onAppear {
            // Auto-load the form when the view appears
            formController.loadFormFromJSON(jsonFormString)
        }
    }
}

/// Preview provider for SwiftUI Canvas
struct LocalFormExample_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            LocalFormExample()
        }
    }
}

/// Example of loading form from a static form builder
struct StaticFormBuilderExample: View {
    var body: some View {
        NavigationView {
            FormBuilder()
                .withFormName("ACH Transfer")
                .addSection(
                    FormSectionBuilder()
                        .withID("transferDetails")
                        .withTitle("Transfer Details")
                        .addElement(
                            FormElementBuilder()
                                .withID("fromAccount")
                                .withType("picker")
                                .withLabel("From Account")
                                .withRequired(true)
                                .withDataSource("userAccounts")
                                .build()
                        )
                        .addElement(
                            FormElementBuilder()
                                .withID("amount")
                                .withType("textField")
                                .withLabel("Amount")
                                .withRequired(true)
                                .withKeyboardType("decimalPad")
                                .withValidation(ValidationRuleBuilder()
                                    .withRegex("^\\d+(\\.\\d{1,2})?$")
                                    .withMinValue(0.01)
                                    .withMaxValue(25000)
                                    .withErrorMessage("Please enter a valid amount")
                                    .build())
                                .build()
                        )
                        .build()
                )
                .buildFormView()
        }
    }
}

/// Form Builder - Fluent API for programmatic form creation
class FormBuilder {
    private var formName: String = "Form"
    private var version: String = "1.0"
    private var sections: [FormSection] = []
    
    func withFormName(_ name: String) -> FormBuilder {
        self.formName = name
        return self
    }
    
    func withVersion(_ version: String) -> FormBuilder {
        self.version = version
        return self
    }
    
    func addSection(_ section: FormSection) -> FormBuilder {
        self.sections.append(section)
        return self
    }
    
    func build() -> FormSpecification {
        // Create default navigation flow if none specified
        let navigationSteps = sections.enumerated().map { (index, section) in
            let nextIndex = index + 1
            let nextStepId = nextIndex < sections.count ? sections[nextIndex].id : "review"
            return NavigationStep(id: section.id, nextStep: nextStepId, validationTrigger: "onContinue")
        }
        
        let navigationFlow = NavigationFlow(steps: navigationSteps)
        
        // Default review screen
        let reviewScreen = ReviewScreen(
            id: "review",
            title: "Review \(formName)",
            showAllFields: true,
            highlightFields: []
        )
        
        // Default actions
        let actions = FormActions(
            submit: ActionDefinition(
                endpoint: "/api/submit",
                method: "POST",
                requiresAuthentication: true,
                successMessage: "Form submitted successfully",
                errorHandler: "displayErrorMessage"
            ),
            save: ActionDefinition(
                endpoint: "/api/save",
                method: "POST",
                requiresAuthentication: true,
                successMessage: "Form saved successfully",
                errorHandler: nil
            ),
            cancel: CancelAction(
                confirmationRequired: true,
                confirmationMessage: "Are you sure you want to cancel?",
                navigateTo: "home"
            )
        )
        
        // Default accessibility options
        let accessibility = AccessibilityOptions(
            voiceOverLabels: [:],
            dynamicTypeSupport: true,
            reduceMotion: true
        )
        
        return FormSpecification(
            formName: formName,
            version: version,
            sections: sections,
            navigationFlow: navigationFlow,
            reviewScreen: reviewScreen,
            actions: actions,
            accessibility: accessibility
        )
    }
    
    func buildFormView() -> some View {
        let formSpecification = build()
        let viewModel = DynamicFormViewModel()
        viewModel.formSpecification = formSpecification
        viewModel.initializeDefaultValues(for: formSpecification)
        
        return DynamicFormView(viewModel: viewModel)
    }
}

/// Form Section Builder
class FormSectionBuilder {
    private var id: String = UUID().uuidString
    private var title: String = "Section"
    private var elements: [FormElement] = []
    
    func withID(_ id: String) -> FormSectionBuilder {
        self.id = id
        return self
    }
    
    func withTitle(_ title: String) -> FormSectionBuilder {
        self.title = title
        return self
    }
    
    func addElement(_ element: FormElement) -> FormSectionBuilder {
        self.elements.append(element)
        return self
    }
    
    func build() -> FormSection {
        return FormSection(id: id, title: title, elements: elements)
    }
}

/// Form Element Builder
class FormElementBuilder {
    private var id: String = UUID().uuidString
    private var type: String = "textField"
    private var label: String = "Field"
    private var required: Bool = false
    private var visibleWhen: VisibilityCondition? = nil
    private var dependentFields: [String: [String]]? = nil
    private var validation: ValidationRule? = nil
    private var defaultValue: FormValueType? = nil
    private var options: [FormElementOption]? = nil
    private var dataSource: String? = nil
    private var displayKey: String? = nil
    private var keyboardType: String? = nil
    private var maxLength: Int? = nil
    private var multiline: Bool? = nil
    private var textContentType: String? = nil
    private var autocapitalizationType: String? = nil
    private var securityType: String? = nil
    private var accessoryView: String? = nil
    private var formatters: [FormatterDefinition]? = nil
    private var minDate: DateConstraint? = nil
    private var maxDate: DateConstraint? = nil
    private var dateFormat: String? = nil
    private var minValue: Double? = nil
    private var maxValue: Double? = nil
    
    func withID(_ id: String) -> FormElementBuilder {
        self.id = id
        return self
    }
    
    func withType(_ type: String) -> FormElementBuilder {
        self.type = type
        return self
    }
    
    func withLabel(_ label: String) -> FormElementBuilder {
        self.label = label
        return self
    }
    
    func withRequired(_ required: Bool) -> FormElementBuilder {
        self.required = required
        return self
    }
    
    func withVisibilityCondition(_ condition: VisibilityCondition) -> FormElementBuilder {
        self.visibleWhen = condition
        return self
    }
    
    func withDependentFields(_ dependentFields: [String: [String]]) -> FormElementBuilder {
        self.dependentFields = dependentFields
        return self
    }
    
    func withValidation(_ validation: ValidationRule) -> FormElementBuilder {
        self.validation = validation
        return self
    }
    
    func withDefaultValue(_ value: FormValueType) -> FormElementBuilder {
        self.defaultValue = value
        return self
    }
    
    func withOptions(_ options: [FormElementOption]) -> FormElementBuilder {
        self.options = options
        return self
    }
    
    func withDataSource(_ dataSource: String) -> FormElementBuilder {
        self.dataSource = dataSource
        return self
    }
    
    func withDisplayKey(_ displayKey: String) -> FormElementBuilder {
        self.displayKey = displayKey
        return self
    }
    
    func withKeyboardType(_ keyboardType: String) -> FormElementBuilder {
        self.keyboardType = keyboardType
        return self
    }
    
    func withMaxLength(_ maxLength: Int) -> FormElementBuilder {
        self.maxLength = maxLength
        return self
    }
    
    func withMultiline(_ multiline: Bool) -> FormElementBuilder {
        self.multiline = multiline
        return self
    }
    
    func build() -> FormElement {
        return FormElement(
            id: id,
            type: type,
            label: label,
            required: required,
            visibleWhen: visibleWhen,
            dependentFields: dependentFields,
            validation: validation,
            defaultValue: defaultValue,
            options: options,
            dataSource: dataSource,
            displayKey: displayKey,
            keyboardType: keyboardType,
            maxLength: maxLength,
            multiline: multiline,
            textContentType: textContentType,
            autocapitalizationType: autocapitalizationType,
            securityType: securityType,
            accessoryView: accessoryView,
            formatters: formatters,
            minDate: minDate,
            maxDate: maxDate,
            dateFormat: dateFormat,
            minValue: minValue,
            maxValue: maxValue
        )
    }
}

/// Validation Rule Builder
class ValidationRuleBuilder {
    private var regex: String? = nil
    private var rule: String? = nil
    private var value: FormValueType? = nil
    private var errorMessage: String = "Invalid input"
    private var minValue: Double? = nil
    private var maxValue: Double? = nil
    private var matchField: String? = nil
    private var checksum: String? = nil
    
    func withRegex(_ regex: String) -> ValidationRuleBuilder {
        self.regex = regex
        return self
    }
    
    func withRule(_ rule: String) -> ValidationRuleBuilder {
        self.rule = rule
        return self
    }
    
    func withValue(_ value: FormValueType) -> ValidationRuleBuilder {
        self.value = value
        return self
    }
    
    func withErrorMessage(_ message: String) -> ValidationRuleBuilder {
        self.errorMessage = message
        return self
    }
    
    func withMinValue(_ value: Double) -> ValidationRuleBuilder {
        self.minValue = value
        return self
    }
    
    func withMaxValue(_ value: Double) -> ValidationRuleBuilder {
        self.maxValue = value
        return self
    }
    
    func withMatchField(_ field: String) -> ValidationRuleBuilder {
        self.matchField = field
        return self
    }
    
    func withChecksum(_ checksum: String) -> ValidationRuleBuilder {
        self.checksum = checksum
        return self
    }
    
    func build() -> ValidationRule {
        return ValidationRule(
            regex: regex,
            rule: rule,
            value: value,
            errorMessage: errorMessage,
            minValue: minValue,
            maxValue: maxValue,
            matchField: matchField,
            checksum: checksum
        )
    }
}
