//
//  SDUIApp.swift
//  SDUI
//
//  Created by Piyush Chhabra on 4/16/25.
//

import SwiftUI

@main
struct SDUIApp: App {
    var body: some Scene {
        WindowGroup {
            LocalFormExample()
        }
    }
}
