import SwiftUI
import Combine

// MARK: - Core Models

/// Main form specification model
struct FormSpecification: Decodable {
    let formName: String
    let version: String
    let sections: [FormSection]
    let navigationFlow: NavigationFlow
    let reviewScreen: ReviewScreen
    let actions: FormActions
    let accessibility: AccessibilityOptions
}

/// A section within the form
struct FormSection: Decodable, Identifiable {
    let id: String
    let title: String
    let elements: [FormElement]
}

/// Navigation flow definition
struct NavigationFlow: Decodable {
    let steps: [NavigationStep]
}

/// A step in the navigation flow
struct NavigationStep: Decodable {
    let id: String
    let nextStep: String
    let validationTrigger: String
}

/// Review screen configuration
struct ReviewScreen: Decodable {
    let id: String
    let title: String
    let showAllFields: Bool
    let highlightFields: [String]
}

/// Form actions configuration
struct FormActions: Decodable {
    let submit: ActionDefinition
    let save: ActionDefinition
    let cancel: CancelAction
}

/// A form action definition
struct ActionDefinition: Decodable {
    let endpoint: String
    let method: String
    let requiresAuthentication: Bool
    let successMessage: String
    let errorHandler: String?
}

/// Cancel action definition
struct CancelAction: Decodable {
    let confirmationRequired: Bool
    let confirmationMessage: String?
    let navigateTo: String
}

/// Accessibility options
struct AccessibilityOptions: Decodable {
    let voiceOverLabels: [String: String]
    let dynamicTypeSupport: Bool
    let reduceMotion: Bool
}

// MARK: - Form Element Models

/// Base protocol for all form elements
protocol DynamicFormElement: Identifiable {
    var id: String { get }
    var type: String { get }
    var label: String { get }
    var required: Bool { get }
    var visibleWhen: VisibilityCondition? { get }
    var dependentFields: [String: [String]]? { get }
    
    /// Function to check if the element should be visible based on current form values
    func isVisible(formValues: [String: Any]) -> Bool
}

/// Base form element properties
struct FormElement: Decodable {
    let id: String
    let type: String
    let label: String
    let required: Bool
    let visibleWhen: VisibilityCondition?
    let dependentFields: [String: [String]]?
    let validation: ValidationRule?
    let defaultValue: FormValueType?
    let options: [FormElementOption]?
    let dataSource: String?
    let displayKey: String?
    let keyboardType: String?
    let maxLength: Int?
    let multiline: Bool?
    let textContentType: String?
    let autocapitalizationType: String?
    let securityType: String?
    let accessoryView: String?
    let formatters: [FormatterDefinition]?
    let minDate: DateConstraint?
    let maxDate: DateConstraint?
    let dateFormat: String?
    let minValue: Double?
    let maxValue: Double?
}

/// Formats for form values
enum FormValueType: Decodable {
    case string(String)
    case integer(Int)
    case double(Double)
    case boolean(Bool)
    case date(Date)
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        
        if let stringValue = try? container.decode(String.self) {
            self = .string(stringValue)
            return
        }
        
        if let intValue = try? container.decode(Int.self) {
            self = .integer(intValue)
            return
        }
        
        if let doubleValue = try? container.decode(Double.self) {
            self = .double(doubleValue)
            return
        }
        
        if let boolValue = try? container.decode(Bool.self) {
            self = .boolean(boolValue)
            return
        }
        
        // For date, we'd need to handle string representation and parse it
        // For simplicity, this case is simplified
        if let dateString = try? container.decode(String.self) {
            let formatter = ISO8601DateFormatter()
            if let date = formatter.date(from: dateString) {
                self = .date(date)
                return
            }
        }
        
        throw DecodingError.dataCorruptedError(
            in: container,
            debugDescription: "Cannot decode form value type"
        )
    }
}

/// Option for selection-based elements
struct FormElementOption: Decodable {
    let id: String
    let label: String
}

/// Condition for element visibility
struct VisibilityCondition: Decodable {
    let field: String
    let equals: FormValueType
}

/// Validation rule for an element
struct ValidationRule: Decodable {
    let regex: String?
    let rule: String?
    let value: FormValueType?
    let errorMessage: String
    let minValue: Double?
    let maxValue: Double?
    let matchField: String?
    let checksum: String?
}

/// Form field formatter
struct FormatterDefinition: Decodable {
    let type: String
    let locale: String?
    let currency: String?
}

/// Date constraint (for date pickers)
enum DateConstraint: Decodable {
    case fixed(String)
    case relative(RelativeDateConstraint)
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        
        if let stringValue = try? container.decode(String.self) {
            self = .fixed(stringValue)
            return
        }
        
        if let relativeConstraint = try? container.decode(RelativeDateConstraint.self) {
            self = .relative(relativeConstraint)
            return
        }
        
        throw DecodingError.dataCorruptedError(
            in: container,
            debugDescription: "Cannot decode date constraint"
        )
    }
}

/// Relative date constraint
struct RelativeDateConstraint: Decodable {
    let dependsOn: String
    let offset: String
}

// MARK: - Form View Models

/// Main view model for the form
class DynamicFormViewModel: ObservableObject {
    @Published var formSpecification: FormSpecification?
    @Published var formValues: [String: Equatable] = [:]
    @Published var formErrors: [String: String] = [:]
    @Published var currentSectionIndex: Int = 0
    @Published var isLoading: Bool = false
    
    private var formLoader = FormLoader()
    private var cancellables: Set<AnyCancellable> = []
    
    init() {}
    
    /// Load form specification from a JSON file
    func loadForm(from jsonUrl: URL) {
        isLoading = true
        
        formLoader.load(from: jsonUrl)
            .receive(on: DispatchQueue.main)
            .sink(
                receiveCompletion: { [weak self] completion in
                    self?.isLoading = false
                    
                    if case .failure(let error) = completion {
                        print("Error loading form: \(error)")
                    }
                },
                receiveValue: { [weak self] specification in
                    self?.formSpecification = specification
                    self?.initializeDefaultValues(for: specification)
                }
            )
            .store(in: &cancellables)
    }
    
    /// Initialize default values from the form specification
    func initializeDefaultValues(for specification: FormSpecification) {
        for section in specification.sections {
            for element in section.elements {
                if let defaultValue = element.defaultValue {
                    switch defaultValue {
                    case .string(let value):
                        formValues[element.id] = value
                    case .integer(let value):
                        formValues[element.id] = value
                    case .double(let value):
                        formValues[element.id] = value
                    case .boolean(let value):
                        formValues[element.id] = value
                    case .date(let value):
                        formValues[element.id] = value
                    }
                }
            }
        }
    }
    
    /// Update a form value
    func updateValue(_ value: Equatable, for elementId: String) {
        formValues[elementId] = value
        validateField(elementId)
        
        // Update dependent fields visibility if needed
        updateDependentFields(for: elementId)
    }
    
    /// Navigate to the next section
    func nextSection() {
        guard let specification = formSpecification else { return }
        
        let currentSection = specification.sections[currentSectionIndex]
        if validateSection(currentSection) {
            if currentSectionIndex < specification.sections.count - 1 {
                currentSectionIndex += 1
            } else {
                // Navigate to review screen
                // This would typically trigger a navigation action
            }
        }
    }
    
    /// Navigate to the previous section
    func previousSection() {
        if currentSectionIndex > 0 {
            currentSectionIndex -= 1
        }
    }
    
    /// Submit the form
    func submitForm() {
        guard let specification = formSpecification else { return }
        
        // Validate all sections before submitting
        var isValid = true
        for section in specification.sections {
            if !validateSection(section) {
                isValid = false
            }
        }
        
        if isValid {
            // Here you would implement the API call based on the action definition
            print("Submitting form to: \(specification.actions.submit.endpoint)")
            print("Form values: \(formValues)")
        }
    }
    
    /// Save form as draft
    func saveFormDraft() {
        guard let specification = formSpecification else { return }
        
        // Here you would implement the API call to save a draft
        print("Saving draft to: \(specification.actions.save.endpoint)")
        print("Form values: \(formValues)")
    }
    
    /// Cancel the form
    func cancelForm(completion: @escaping (Bool) -> Void) {
        guard let specification = formSpecification else {
            completion(true)
            return
        }
        
        if specification.actions.cancel.confirmationRequired {
            // The view would show a confirmation alert
            // For now, we just simulate it
            print("Cancel confirmation: \(specification.actions.cancel.confirmationMessage ?? "Are you sure?")")
            
            // In a real app, this would wait for user confirmation
            // For this example, we just proceed
            completion(true)
        } else {
            completion(true)
        }
    }
    
    /// Validate a specific field
    private func validateField(_ elementId: String) -> Bool {
        guard let specification = formSpecification else { return true }
        
        // Find the element in all sections
        for section in specification.sections {
            if let element = section.elements.first(where: { $0.id == elementId }),
               let validation = element.validation {
                
                // Get the current value
                let value = formValues[elementId]
                
                // Clear any existing error
                formErrors.removeValue(forKey: elementId)
                
                // Perform validation based on the rule type
                if let regex = validation.regex, let stringValue = value as? String {
                    let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
                    if !predicate.evaluate(with: stringValue) {
                        formErrors[elementId] = validation.errorMessage
                        return false
                    }
                }
                
                if let rule = validation.rule {
                    switch rule {
                    case "isTrue":
                        if let boolValue = value as? Bool, !boolValue {
                            formErrors[elementId] = validation.errorMessage
                            return false
                        }
                        
                    case "hasMinimumBalance":
                        if let requiredBalance = validation.value, case .double(let minBalance) = requiredBalance {
                            // This would check against an account balance
                            // For this example, we assume it passes
                        }
                        
                    default:
                        break
                    }
                }
                
                // Match field validation
                if let matchField = validation.matchField {
                    let matchValue = formValues[matchField]
                    if let val1 = value as? String, let val2 = matchValue as? String {
                        if(val1 != val2) {
                            formErrors[elementId] = validation.errorMessage
                            return false
                        }
                    }
                }
                
                // Min/max value validation
                if let numericValue = value as? Double {
                    if let minValue = validation.minValue, numericValue < minValue {
                        formErrors[elementId] = validation.errorMessage
                        return false
                    }
                    
                    if let maxValue = validation.maxValue, numericValue > maxValue {
                        formErrors[elementId] = validation.errorMessage
                        return false
                    }
                }
                
                // Checksum validation (e.g. for routing numbers)
                if let checksum = validation.checksum, checksum == "abaRoutingChecksum",
                   let routingString = value as? String, routingString.count == 9 {
                    if !validateABARoutingNumber(routingString) {
                        formErrors[elementId] = validation.errorMessage
                        return false
                    }
                }
                
                return true
            }
        }
        
        return true
    }
    
    /// Validate an entire section
    private func validateSection(_ section: FormSection) -> Bool {
        var isValid = true
        
        for element in section.elements {
            // Only validate fields that are currently visible and required
            if isElementVisible(element) && element.required {
                if formValues[element.id] == nil {
                    formErrors[element.id] = "This field is required"
                    isValid = false
                } else if !validateField(element.id) {
                    isValid = false
                }
            }
        }
        
        return isValid
    }
    
    /// Check if an element should be visible based on current form values
    func isElementVisible(_ element: FormElement) -> Bool {
        if let visibilityCondition = element.visibleWhen {
            let dependentFieldId = visibilityCondition.field
            let dependentValue = formValues[dependentFieldId]
            
            switch visibilityCondition.equals {
            case .string(let targetValue):
                return dependentValue as? String == targetValue
            case .integer(let targetValue):
                return dependentValue as? Int == targetValue
            case .double(let targetValue):
                return dependentValue as? Double == targetValue
            case .boolean(let targetValue):
                return dependentValue as? Bool == targetValue
            case .date(let targetValue):
                return dependentValue as? Date == targetValue
            }
        }
        
        return true
    }
    
    /// Update dependent fields when a field's value changes
    private func updateDependentFields(for elementId: String) {
        guard let specification = formSpecification else { return }
        
        for section in specification.sections {
            for element in section.elements {
                if element.id == elementId, let dependentFields = element.dependentFields {
                    // Get the current value for the element
                    if let value = formValues[elementId] {
                        // Convert value to string for dictionary key lookup
                        let valueKey: String
                        
                        if let boolValue = value as? Bool {
                            valueKey = String(boolValue)
                        } else {
                            valueKey = String(describing: value)
                        }
                        
                        // Process any dependent fields for this value
                        if let fieldsToProcess = dependentFields[valueKey] {
                            // This indicates fields that should be shown for this value
                            // You may need to handle this differently based on your UI implementation
                            print("Fields to process for \(elementId) = \(value): \(fieldsToProcess)")
                        }
                    }
                }
            }
        }
    }
    
    /// Validate ABA routing number using the checksum algorithm
    private func validateABARoutingNumber(_ routingNumber: String) -> Bool {
        guard routingNumber.count == 9, let _ = Int(routingNumber) else {
            return false
        }
        
        // ABA routing number checksum algorithm
        let digits = routingNumber.compactMap { Int(String($0)) }
        let weightedSum = digits[0] * 3 + digits[1] * 7 + digits[2] * 1 +
                          digits[3] * 3 + digits[4] * 7 + digits[5] * 1 +
                          digits[6] * 3 + digits[7] * 7 + digits[8] * 1
        
        return weightedSum % 10 == 0
    }
}

// MARK: - Form Loader

/// Responsible for loading form specifications from JSON
class FormLoader {
    func load(from url: URL) -> AnyPublisher<FormSpecification, Error> {
        return URLSession.shared.dataTaskPublisher(for: url)
            .map { $0.data }
            .decode(type: FormSpecification.self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
    
    func load(from data: Data) -> AnyPublisher<FormSpecification, Error> {
        return Just(data)
            .decode(type: FormSpecification.self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
}

// MARK: - Form View Components (Refactored)

/// DynamicFormView - Main container for the form (refactored to reduce complexity)
struct DynamicFormView: View {
    @ObservedObject var viewModel: DynamicFormViewModel
    @State private var showCancelConfirmation = false
    
    var body: some View {
        NavigationView {
            ZStack {
                if viewModel.isLoading {
                    LoadingView()
                } else if let specification = viewModel.formSpecification {
                    FormContentView(viewModel: viewModel, specification: specification)
                        .navigationBarItems(trailing: cancelButton)
                        .alert(isPresented: $showCancelConfirmation) {
                            createCancelAlert(specification: specification)
                        }
                } else {
//                    FormErrorView()
                }
            }
            .navigationTitle(viewModel.formSpecification?.formName ?? "Form")
        }
    }
    
    // MARK: - Subviews and Components
    
    private var cancelButton: some View {
        Button("Cancel") {
            if viewModel.formSpecification?.actions.cancel.confirmationRequired == true {
                showCancelConfirmation = true
            } else {
                viewModel.cancelForm { _ in
                    // Handle navigation back
                }
            }
        }
    }
    
    private func createCancelAlert(specification: FormSpecification) -> Alert {
        Alert(
            title: Text("Cancel Form"),
            message: Text(specification.actions.cancel.confirmationMessage ?? "Are you sure you want to cancel?"),
            primaryButton: .destructive(Text("Yes")) {
                viewModel.cancelForm { _ in
                    // Handle navigation back
                }
            },
            secondaryButton: .cancel()
        )
    }
}

/// Loading view for when the form is loading
struct LoadingView: View {
    var body: some View {
        ProgressView("Loading form...")
    }
}

///// Error view for when the form fails to load
//struct FormErrorView: View {
//    var body: some View {
//        Text("Form could not be loaded")
//            .foregroundColor(.red)
//    }
//}

/// Main content view for the form
struct FormContentView: View {
    @ObservedObject var viewModel: DynamicFormViewModel
    let specification: FormSpecification
    
    var body: some View {
        VStack {
            // Form progress indicator
            ProgressView(value: Double(viewModel.currentSectionIndex + 1),
                         total: Double(specification.sections.count))
                .padding()
            
            // Current section
            if viewModel.currentSectionIndex < specification.sections.count {
                let section = specification.sections[viewModel.currentSectionIndex]
                FormSectionView(
                    viewModel: viewModel,
                    section: section
                )
                
                // Navigation buttons
                FormNavigationView(
                    viewModel: viewModel,
                    currentIndex: viewModel.currentSectionIndex,
                    totalSections: specification.sections.count
                )
            }
        }
    }
}

/// View for a single form section
struct FormSectionView: View {
    @ObservedObject var viewModel: DynamicFormViewModel
    let section: FormSection
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text(section.title)
                    .font(.headline)
                    .padding(.bottom, 5)
                
                // Render elements for the current section
                ForEach(section.elements, id: \.id) { element in
                    if viewModel.isElementVisible(element) {
                        FormElementView(
                            element: element,
                            formValues: viewModel.formValues,
                            formErrors: viewModel.formErrors,
                            updateValue: { value in
                                viewModel.updateValue(value as! Equatable, for: element.id)
                            }
                        )
                    }
                }
            }
            .padding()
        }
    }
}

/// Navigation buttons for the form
struct FormNavigationView: View {
    @ObservedObject var viewModel: DynamicFormViewModel
    let currentIndex: Int
    let totalSections: Int
    
    var body: some View {
        HStack {
            if currentIndex > 0 {
                Button("Previous") {
                    viewModel.previousSection()
                }
                .padding()
            }
            
            Spacer()
            
            if currentIndex < totalSections - 1 {
                Button("Next") {
                    viewModel.nextSection()
                }
                .padding()
            } else {
                Button("Review") {
                    // Navigate to review screen
                    // This would typically be handled by your navigation system
                }
                .padding()
            }
        }
        .padding(.horizontal)
    }
}

/// FormElementView - Renders a single form element based on its type
//struct FormElementView: View {
//    let element: FormElement
//    let formValues: [String: Any]
//    let formErrors: [String: String]
//    let updateValue: (Any) -> Void
//    
//    var body: some View {
//        VStack(alignment: .leading) {
//            // Element label with required indicator
//            FormElementLabelView(element: element)
//            
//            // Element input based on type
//            FormElementInputView(
//                element: element,
//                formValues: formValues,
//                updateValue: updateValue
//            )
//            
//            // Error message if any
//            if let errorMessage = formErrors[element.id] {
//                Text(errorMessage)
//                    .font(.caption)
//                    .foregroundColor(.red)
//            }
//        }
//    }
//}

/// Label view for a form element
struct FormElementLabelView: View {
    let element: FormElement
    
    var body: some View {
        HStack {
            Text(element.label)
                .font(.subheadline)
                .foregroundColor(.primary)
            
            if element.required {
                Text("*")
                    .foregroundColor(.red)
            }
        }
    }
}

/// Input view for a form element based on its type
struct FormElementInputView: View {
    let element: FormElement
    let formValues: [String: Any]
    let updateValue: (Any) -> Void
    
    var body: some View {
        switch element.type {
        case "textField":
            TextFieldElementView(
                element: element,
                value: formValueAsString(element.id, in: formValues),
                updateValue: updateValue
            )
            
        case "datePicker":
            DatePickerElementView(
                element: element,
                value: formValueAsDate(element.id, in: formValues) ?? Date(),
                updateValue: updateValue
            )
            
        case "picker":
            PickerElementView(
                element: element,
                value: formValueAsString(element.id, in: formValues),
                updateValue: updateValue
            )
            
        case "segmentedControl":
            SegmentedControlView(
                element: element,
                value: formValueAsString(element.id, in: formValues),
                updateValue: updateValue
            )
            
        case "toggle":
            ToggleElementView(
                element: element,
                value: formValueAsBool(element.id, in: formValues),
                updateValue: updateValue
            )
            
        case "checkbox":
            CheckboxElementView(
                element: element,
                value: formValueAsBool(element.id, in: formValues),
                updateValue: updateValue
            )
            
        default:
            Text("Unsupported element type: \(element.type)")
                .foregroundColor(.red)
        }
    }
    
    // Helper methods to convert form values to appropriate types
    private func formValueAsString(_ elementId: String, in formValues: [String: Any]) -> String {
        if let value = formValues[elementId] as? String {
            return value
        }
        return ""
    }
    
    private func formValueAsBool(_ elementId: String, in formValues: [String: Any]) -> Bool {
        if let value = formValues[elementId] as? Bool {
            return value
        }
        return false
    }
    
    private func formValueAsDate(_ elementId: String, in formValues: [String: Any]) -> Date? {
        return formValues[elementId] as? Date
    }
}




/*// MARK: - Form View Components

/// DynamicFormView - Main container for the form
struct DynamicFormView: View {
    @ObservedObject var viewModel: DynamicFormViewModel
    @State private var showCancelConfirmation = false
    
    var body: some View {
        NavigationView {
            VStack {
                if viewModel.isLoading {
                    ProgressView("Loading form...")
                } else if let specification = viewModel.formSpecification {
                    VStack {
                        // Form progress indicator
                        ProgressView(value: Double(viewModel.currentSectionIndex + 1),
                                     total: Double(specification.sections.count))
                            .padding()
                        
                        // Current section
                        if viewModel.currentSectionIndex < specification.sections.count {
                            let section = specification.sections[viewModel.currentSectionIndex]
                            
                            ScrollView {
                                VStack(alignment: .leading, spacing: 20) {
                                    Text(section.title)
                                        .font(.headline)
                                        .padding(.bottom, 5)
                                    
                                    // Render elements for the current section
                                    ForEach(section.elements, id: \.id) { element in
                                        if viewModel.isElementVisible(element) {
                                            FormElementView(
                                                element: element,
                                                formValues: viewModel.formValues,
                                                formErrors: viewModel.formErrors,
                                                updateValue: { value in
                                                    viewModel.updateValue(value, for: element.id)
                                                }
                                            )
                                        }
                                    }
                                }
                                .padding()
                            }
                            
                            // Navigation buttons
                            HStack {
                                if viewModel.currentSectionIndex > 0 {
                                    Button("Previous") {
                                        viewModel.previousSection()
                                    }
                                    .padding()
                                }
                                
                                Spacer()
                                
                                if viewModel.currentSectionIndex < specification.sections.count - 1 {
                                    Button("Next") {
                                        viewModel.nextSection()
                                    }
                                    .padding()
                                } else {
                                    Button("Review") {
                                        // Navigate to review screen
                                        // This would typically be handled by your navigation system
                                    }
                                    .padding()
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                } else {
                    Text("Form could not be loaded")
                        .foregroundColor(.red)
                }
            }
            .navigationTitle(viewModel.formSpecification?.formName ?? "Form")
            .navigationBarItems(
                trailing: Button("Cancel") {
                    if viewModel.formSpecification?.actions.cancel.confirmationRequired == true {
                        showCancelConfirmation = true
                    } else {
                        viewModel.cancelForm { _ in
                            // Handle navigation back
                        }
                    }
                }
            )
            .alert(isPresented: $showCancelConfirmation) {
                Alert(
                    title: Text("Cancel Form"),
                    message: Text(viewModel.formSpecification?.actions.cancel.confirmationMessage ?? "Are you sure you want to cancel?"),
                    primaryButton: .destructive(Text("Yes")) {
                        viewModel.cancelForm { _ in
                            // Handle navigation back
                        }
                    },
                    secondaryButton: .cancel()
                )
            }
        }
    }
}
 */

/// FormElementView - Renders a single form element based on its type
struct FormElementView: View {
    let element: FormElement
    let formValues: [String: Any]
    let formErrors: [String: String]
    let updateValue: (Any) -> Void
    
    var body: some View {
        VStack(alignment: .leading) {
            // Element label with required indicator
            HStack {
                Text(element.label)
                    .font(.subheadline)
                    .foregroundColor(.primary)
                
                if element.required {
                    Text("*")
                        .foregroundColor(.red)
                }
            }
            
            // Element input based on type
            switch element.type {
            case "textField":
                TextFieldElementView(
                    element: element,
                    value: formValueAsString(),
                    updateValue: updateValue
                )
                
            case "datePicker":
                DatePickerElementView(
                    element: element,
                    value: formValueAsDate() ?? Date(),
                    updateValue: updateValue
                )
                
            case "picker":
                PickerElementView(
                    element: element,
                    value: formValueAsString(),
                    updateValue: updateValue
                )
                
            case "segmentedControl":
                SegmentedControlView(
                    element: element,
                    value: formValueAsString(),
                    updateValue: updateValue
                )
                
            case "toggle":
                ToggleElementView(
                    element: element,
                    value: formValueAsBool(),
                    updateValue: updateValue
                )
                
            case "checkbox":
                CheckboxElementView(
                    element: element,
                    value: formValueAsBool(),
                    updateValue: updateValue
                )
                
            default:
                Text("Unsupported element type: \(element.type)")
                    .foregroundColor(.red)
            }
            
            // Error message if any
            if let errorMessage = formErrors[element.id] {
                Text(errorMessage)
                    .font(.caption)
                    .foregroundColor(.red)
            }
        }
    }
    
    // Helper methods to convert form values to appropriate types
    private func formValueAsString() -> String {
        if let value = formValues[element.id] as? String {
            return value
        }
        return ""
    }
    
    private func formValueAsInt() -> Int {
        if let value = formValues[element.id] as? Int {
            return value
        }
        return 0
    }
    
    private func formValueAsDouble() -> Double {
        if let value = formValues[element.id] as? Double {
            return value
        }
        return 0.0
    }
    
    private func formValueAsBool() -> Bool {
        if let value = formValues[element.id] as? Bool {
            return value
        }
        return false
    }
    
    private func formValueAsDate() -> Date? {
        return formValues[element.id] as? Date
    }
}

// MARK: - Element-Specific Views

/// Text Field Element View
struct TextFieldElementView: View {
    let element: FormElement
    @State var value: String
    let updateValue: (Any) -> Void
    
    var body: some View {
        VStack {
            if element.multiline == true {
                TextEditor(text: $value)
                    .onChange(of: value) { newValue in
                        updateValue(newValue)
                    }
                    .frame(height: 100)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color.gray, lineWidth: 1)
                    )
            } else {
                TextField("Enter \(element.label.lowercased())", text: $value)
                    .onChange(of: value) { newValue in
                        updateValue(newValue)
                    }
                    .keyboardType(keyboardType())
                    .textContentType(textContentType())
                    .autocapitalization(autocapitalizationType())
                    .disableAutocorrection(element.textContentType == "emailAddress")
                    .if(element.securityType == "sensitive") { view in
                        view.privacySensitive()
                    }
                    .if(element.maxLength != nil) { view in
                        view.onReceive(Just(value)) { _ in
                            if let maxLength = element.maxLength, value.count > maxLength {
                                value = String(value.prefix(maxLength))
                            }
                        }
                    }
                    .padding()
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color.gray, lineWidth: 1)
                    )
            }
        }
    }
    
    private func keyboardType() -> UIKeyboardType {
        switch element.keyboardType {
        case "emailAddress":
            return .emailAddress
        case "numberPad":
            return .numberPad
        case "decimalPad":
            return .decimalPad
        case "phonePad":
            return .phonePad
        default:
            return .default
        }
    }
    
    private func textContentType() -> UITextContentType? {
        switch element.textContentType {
        case "emailAddress":
            return .emailAddress
        case "name":
            return .name
        case "telephoneNumber":
            return .telephoneNumber
        default:
            return nil
        }
    }
    
    private func autocapitalizationType() -> UITextAutocapitalizationType {
        switch element.autocapitalizationType {
        case "words":
            return .words
        case "sentences":
            return .sentences
        case "allCharacters":
            return .allCharacters
        case "none":
            return .none
        default:
            return .sentences
        }
    }
}

/// Date Picker Element View
struct DatePickerElementView: View {
    let element: FormElement
    @State var value: Date
    let updateValue: (Any) -> Void
    
    var body: some View {
        DatePicker(
            "",
            selection: $value,
            in: dateRange(),
            displayedComponents: .date
        )
        .onChange(of: value) { newValue in
            updateValue(newValue)
        }
        .padding()
        .overlay(
            RoundedRectangle(cornerRadius: 5)
                .stroke(Color.gray, lineWidth: 1)
        )
    }
    
    private func dateRange() -> ClosedRange<Date> {
        let calendar = Calendar.current
        
        let minDate: Date
        if let minConstraint = element.minDate {
            switch minConstraint {
            case .fixed(let dateString):
                if dateString == "currentDate" {
                    minDate = Date()
                } else if dateString == "currentDatePlus180Days" {
                    minDate = calendar.date(byAdding: .day, value: 180, to: Date()) ?? Date()
                } else {
                    // Default to current date if parsing fails
                    minDate = Date()
                }
            case .relative(let relativeConstraint):
                // This would need to access the dependent field's date
                // For simplicity, we'll use current date
                minDate = Date()
            }
        } else {
            minDate = calendar.date(byAdding: .year, value: -10, to: Date()) ?? Date()
        }
        
        let maxDate: Date
        if let maxConstraint = element.maxDate {
            switch maxConstraint {
            case .fixed(let dateString):
                if dateString == "currentDatePlus180Days" {
                    maxDate = calendar.date(byAdding: .day, value: 180, to: Date()) ?? Date()
                } else if dateString == "currentDatePlus5Years" {
                    maxDate = calendar.date(byAdding: .year, value: 5, to: Date()) ?? Date()
                } else {
                    // Default to far future if parsing fails
                    maxDate = calendar.date(byAdding: .year, value: 10, to: Date()) ?? Date()
                }
            case .relative(let relativeConstraint):
                // This would need to access the dependent field's date
                // For simplicity, we'll use far future
                maxDate = calendar.date(byAdding: .year, value: 10, to: Date()) ?? Date()
            }
        } else {
            maxDate = calendar.date(byAdding: .year, value: 10, to: Date()) ?? Date()
        }
        
        return minDate...maxDate
    }
}

/// Picker Element View
struct PickerElementView: View {
    let element: FormElement
    @State var value: String
    let updateValue: (Any) -> Void
    
    var body: some View {
        if let options = element.options {
            Picker(selection: $value) {
                ForEach(options, id: \.id) { option in
                    Text(option.label)
                        .tag(option.id)
                }
            } label: {
                EmptyView()
            }
            .onChange(of: value) { newValue in
                updateValue(newValue)
            }
            .pickerStyle(MenuPickerStyle())
            .padding()
            .overlay(
                RoundedRectangle(cornerRadius: 5)
                    .stroke(Color.gray, lineWidth: 1)
            )
        } else if let dataSource = element.dataSource {
            // For data sources like "userAccounts" or "savedRecipients"
            // In a real app, you would fetch this data
            Text("Data from \(dataSource)")
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 5)
                        .stroke(Color.gray, lineWidth: 1)
                )
        }
    }
}

/// Segmented Control View
struct SegmentedControlView: View {
    let element: FormElement
    @State var value: String
    let updateValue: (Any) -> Void
    
    var body: some View {
        if let options = element.options {
            Picker("", selection: $value) {
                ForEach(options, id: \.id) { option in
                    Text(option.label)
                        .tag(option.id)
                }
            }
            .onChange(of: value) { newValue in
                updateValue(newValue)
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding(.vertical)
        }
    }
}

/// Toggle Element View
struct ToggleElementView: View {
    let element: FormElement
    @State var value: Bool
    let updateValue: (Any) -> Void
    
    var body: some View {
        Toggle(isOn: $value) {
            // Toggle label is rendered separately
            EmptyView()
        }
        .onChange(of: value) { newValue in
            updateValue(newValue)
        }
        .padding(.vertical, 8)
    }
}

/// Checkbox Element View
struct CheckboxElementView: View {
    let element: FormElement
    @State var value: Bool
    let updateValue: (Any) -> Void
    
    var body: some View {
        Button(action: {
            value.toggle()
            updateValue(value)
        }) {
            HStack {
                Image(systemName: value ? "checkmark.square.fill" : "square")
                    .foregroundColor(value ? .blue : .gray)
                Text(element.label)
                    .foregroundColor(.primary)
                    .font(.body)
                Spacer()
            }
        }
        .buttonStyle(PlainButtonStyle())
        .padding(.vertical, 8)
    }
}

// MARK: - Review Screen Components

/// Review Screen View
struct ReviewScreenView: View {
    let specification: FormSpecification
    let formValues: [String: Any]
    let onSubmit: () -> Void
    let onEdit: () -> Void
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text(specification.reviewScreen.title)
                    .font(.headline)
                    .padding(.bottom, 5)
                
                ForEach(specification.sections) { section in
                    VStack(alignment: .leading, spacing: 12) {
                        Text(section.title)
                            .font(.subheadline)
                            .fontWeight(.semibold)
                        
                        // Show all elements that have values
                        ForEach(section.elements, id: \.id) { element in
                            if let value = formValues[element.id], shouldShowElement(element) {
                                ReviewElementRow(
                                    element: element,
                                    value: value,
                                    isHighlighted: specification.reviewScreen.highlightFields.contains(element.id)
                                )
                            }
                        }
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                }
                
                // Action buttons
                HStack {
                    Button("Edit") {
                        onEdit()
                    }
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(8)
                    
                    Spacer()
                    
                    Button("Submit") {
                        onSubmit()
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                }
                .padding(.top)
            }
            .padding()
        }
    }
    
    private func shouldShowElement(_ element: FormElement) -> Bool {
        // Show all fields if specified in review screen config
        if specification.reviewScreen.showAllFields {
            return true
        }
        
        // Otherwise, only show highlighted fields
        return specification.reviewScreen.highlightFields.contains(element.id)
    }
}

/// Review Element Row - Displays a form element value in the review screen
struct ReviewElementRow: View {
    let element: FormElement
    let value: Any
    let isHighlighted: Bool
    
    var body: some View {
        HStack(alignment: .top) {
            Text(element.label)
                .font(.caption)
                .foregroundColor(.secondary)
                .frame(width: 120, alignment: .leading)
            
            Spacer()
            
            Text(formattedValue())
                .font(.body)
                .multilineTextAlignment(.trailing)
                .foregroundColor(isHighlighted ? .blue : .primary)
                .fontWeight(isHighlighted ? .bold : .regular)
        }
        .padding(.vertical, 4)
    }
    
    private func formattedValue() -> String {
        if let stringValue = value as? String {
            return stringValue
        } else if let boolValue = value as? Bool {
            return boolValue ? "Yes" : "No"
        } else if let dateValue = value as? Date {
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            return formatter.string(from: dateValue)
        } else if let doubleValue = value as? Double {
            // Format currency if this is an amount field
            if element.id == "amount" {
                let formatter = NumberFormatter()
                formatter.numberStyle = .currency
                formatter.currencyCode = "USD"
                return formatter.string(from: NSNumber(value: doubleValue)) ?? "\(doubleValue)"
            }
            return "\(doubleValue)"
        } else if let intValue = value as? Int {
            return "\(intValue)"
        } else {
            return "\(value)"
        }
    }
}

// MARK: - Currency Formatter

/// Currency formatter view wrapper for text fields
struct CurrencyTextField: View {
    let element: FormElement
    @Binding var value: Double
    let updateValue: (Any) -> Void
    @State private var text: String = ""
    
    private let currencyFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = "USD"
        return formatter
    }()
    
    var body: some View {
        TextField("Enter amount", text: $text, onEditingChanged: { isEditing in
            if !isEditing {
                // When editing ends, format the text and update the value
                if let number = currencyFormatter.number(from: text)?.doubleValue {
                    value = number
                    updateValue(number)
                    // Format the text with currency symbol
                    text = currencyFormatter.string(from: NSNumber(value: number)) ?? ""
                }
            }
        })
        .keyboardType(.decimalPad)
        .padding()
        .overlay(
            RoundedRectangle(cornerRadius: 5)
                .stroke(Color.gray, lineWidth: 1)
        )
        .onAppear {
            // Initialize text with formatted value
            text = currencyFormatter.string(from: NSNumber(value: value)) ?? ""
        }
    }
}

// MARK: - Form Field Formatting

/// Protocol for form field formatters
protocol FormFieldFormatter {
    func format(_ value: Any) -> String
    func parse(_ string: String) -> Any?
}

/// Currency formatter implementation
struct CurrencyFieldFormatter: FormFieldFormatter {
    private let formatter: NumberFormatter
    
    init(locale: String = "en_US", currency: String = "USD") {
        formatter = NumberFormatter()
        formatter.numberStyle = .currency
        
//        if let localeObj = Locale(identifier: locale) {
            formatter.locale = Locale(identifier: locale)
//        }
        
        formatter.currencyCode = currency
    }
    
    func format(_ value: Any) -> String {
        guard let number = value as? NSNumber else {
            return ""
        }
        
        return formatter.string(from: number) ?? ""
    }
    
    func parse(_ string: String) -> Any? {
        return formatter.number(from: string)?.doubleValue
    }
}

/// Date formatter implementation
struct DateFieldFormatter: FormFieldFormatter {
    private let formatter: DateFormatter
    
    init(dateFormat: String = "MM/dd/yyyy") {
        formatter = DateFormatter()
        formatter.dateFormat = dateFormat
    }
    
    func format(_ value: Any) -> String {
        guard let date = value as? Date else {
            return ""
        }
        
        return formatter.string(from: date)
    }
    
    func parse(_ string: String) -> Any? {
        return formatter.date(from: string)
    }
}

// MARK: - Form Field Validation

/// Protocol for form field validators
protocol FormFieldValidator {
    func validate(_ value: Any?) -> Bool
    var errorMessage: String { get }
}

/// Regex validator implementation
struct RegexValidator: FormFieldValidator {
    let pattern: String
    let errorMessage: String
    
    func validate(_ value: Any?) -> Bool {
        guard let stringValue = value as? String else {
            return false
        }
        
        let predicate = NSPredicate(format: "SELF MATCHES %@", pattern)
        return predicate.evaluate(with: stringValue)
    }
}

/// Required field validator
struct RequiredValidator: FormFieldValidator {
    let errorMessage: String
    
    func validate(_ value: Any?) -> Bool {
        if let string = value as? String {
            return !string.isEmpty
        }
        return value != nil
    }
}

/// Range validator for numeric values
struct RangeValidator: FormFieldValidator {
    let min: Double?
    let max: Double?
    let errorMessage: String
    
    func validate(_ value: Any?) -> Bool {
        guard let number = value as? Double else {
            return false
        }
        
        if let min = min, number < min {
            return false
        }
        
        if let max = max, number > max {
            return false
        }
        
        return true
    }
}

/// Field matching validator
struct MatchingValidator: FormFieldValidator {
    let errorMessage: String
    let matchValue: Any?
    
    func validate(_ value: Any?) -> Bool {
        // Simple equality check, could be enhanced for specific types
        return value as? String == matchValue as? String
    }
}

// MARK: - Form State Management

/// Form state manager to handle more complex state transitions
class FormStateManager: ObservableObject {
    @Published var currentState: FormState = .initial
    @Published var sections: [FormSection] = []
    @Published var currentSectionIndex: Int = 0
    @Published var formValues: [String: Any] = [:]
    @Published var formErrors: [String: String] = [:]
    
    enum FormState {
        case initial
        case loading
        case editing
        case reviewing
        case submitting
        case completed
        case error(String)
    }
    
    func moveToNextSection() {
        if currentSectionIndex < sections.count - 1 {
            currentSectionIndex += 1
        } else {
            currentState = .reviewing
        }
    }
    
    func moveToPreviousSection() {
        if currentSectionIndex > 0 {
            currentSectionIndex -= 1
        }
    }
    
    func submitForm() {
        currentState = .submitting
        // Handle form submission logic
    }
    
    func resetForm() {
        currentState = .initial
        currentSectionIndex = 0
        formValues = [:]
        formErrors = [:]
    }
}

// MARK: - Utility Extensions

extension View {
    /// Conditional modifier application
    @ViewBuilder func `if`<Content: View>(_ condition: Bool, transform: (Self) -> Content) -> some View {
        if condition {
            transform(self)
        } else {
            self
        }
    }
}

// MARK: - Accessibility Extensions

extension View {
    /// Add accessibility label from form specification
    func accessibilityLabel(from element: FormElement, in accessibilityOptions: AccessibilityOptions) -> some View {
        if let label = accessibilityOptions.voiceOverLabels[element.id] {
            return self.accessibilityLabel(label)
        }
        return self.accessibilityLabel(element.label)
    }
    
//    /// Add dynamic type support
//    func withDynamicTypeSupport(_ enabled: Bool) -> some View {
//        if enabled {
//            return self.dynamicTypeSize(.large)
//        }
//        return self
//    }
//    
    /// Add reduced motion support
    func withReducedMotion(_ enabled: Bool) -> some View {
        // In a real app, you would implement motion reduction
        return self
    }
}

// MARK: - Form Navigation Management

/// Protocol for form navigation
protocol FormNavigationController {
    func navigateToSection(_ sectionId: String)
    func navigateToNextSection()
    func navigateToPreviousSection()
    func navigateToReview()
    func navigateToCompletion()
}

/// Implementation of form navigation
class DefaultFormNavigationController: FormNavigationController {
    private let viewModel: DynamicFormViewModel
    
    init(viewModel: DynamicFormViewModel) {
        self.viewModel = viewModel
    }
    
    func navigateToSection(_ sectionId: String) {
        guard let specification = viewModel.formSpecification else { return }
        
        if let index = specification.sections.firstIndex(where: { $0.id == sectionId }) {
            viewModel.currentSectionIndex = index
        }
    }
    
    func navigateToNextSection() {
        viewModel.nextSection()
    }
    
    func navigateToPreviousSection() {
        viewModel.previousSection()
    }
    
    func navigateToReview() {
        // This would be implemented in the coordinator
    }
    
    func navigateToCompletion() {
        // This would be implemented in the coordinator
    }
}




/*import SwiftUI
import Combine

// MARK: - Core Models

/// Main form specification model
struct FormSpecification: Decodable {
    let formName: String
    let version: String
    let sections: [FormSection]
    let navigationFlow: NavigationFlow
    let reviewScreen: ReviewScreen
    let actions: FormActions
    let accessibility: AccessibilityOptions
}

/// A section within the form
struct FormSection: Decodable, Identifiable {
    let id: String
    let title: String
    let elements: [FormElement]
}

/// Navigation flow definition
struct NavigationFlow: Decodable {
    let steps: [NavigationStep]
}

/// A step in the navigation flow
struct NavigationStep: Decodable {
    let id: String
    let nextStep: String
    let validationTrigger: String
}

/// Review screen configuration
struct ReviewScreen: Decodable {
    let id: String
    let title: String
    let showAllFields: Bool
    let highlightFields: [String]
}

/// Form actions configuration
struct FormActions: Decodable {
    let submit: ActionDefinition
    let save: ActionDefinition
    let cancel: CancelAction
}

/// A form action definition
struct ActionDefinition: Decodable {
    let endpoint: String
    let method: String
    let requiresAuthentication: Bool
    let successMessage: String
    let errorHandler: String?
}

/// Cancel action definition
struct CancelAction: Decodable {
    let confirmationRequired: Bool
    let confirmationMessage: String?
    let navigateTo: String
}

/// Accessibility options
struct AccessibilityOptions: Decodable {
    let voiceOverLabels: [String: String]
    let dynamicTypeSupport: Bool
    let reduceMotion: Bool
}

// MARK: - Form Element Models

/// Base protocol for all form elements
protocol DynamicFormElement: Identifiable {
    var id: String { get }
    var type: String { get }
    var label: String { get }
    var required: Bool { get }
    var visibleWhen: VisibilityCondition? { get }
    var dependentFields: [String: [String]]? { get }
    
    /// Function to check if the element should be visible based on current form values
    func isVisible(formValues: [String: Any]) -> Bool
}

/// Base form element properties
struct FormElement: Decodable {
    let id: String
    let type: String
    let label: String
    let required: Bool
    let visibleWhen: VisibilityCondition?
    let dependentFields: [String: [String]]?
    let validation: ValidationRule?
    let defaultValue: FormValueType?
    let options: [FormElementOption]?
    let dataSource: String?
    let displayKey: String?
    let keyboardType: String?
    let maxLength: Int?
    let multiline: Bool?
    let textContentType: String?
    let autocapitalizationType: String?
    let securityType: String?
    let accessoryView: String?
    let formatters: [FormatterDefinition]?
    let minDate: DateConstraint?
    let maxDate: DateConstraint?
    let dateFormat: String?
    let minValue: Double?
    let maxValue: Double?
}

/// Formats for form values
enum FormValueType: Decodable {
    case string(String)
    case integer(Int)
    case double(Double)
    case boolean(Bool)
    case date(Date)
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        
        if let stringValue = try? container.decode(String.self) {
            self = .string(stringValue)
            return
        }
        
        if let intValue = try? container.decode(Int.self) {
            self = .integer(intValue)
            return
        }
        
        if let doubleValue = try? container.decode(Double.self) {
            self = .double(doubleValue)
            return
        }
        
        if let boolValue = try? container.decode(Bool.self) {
            self = .boolean(boolValue)
            return
        }
        
        // For date, we'd need to handle string representation and parse it
        // For simplicity, this case is simplified
        if let dateString = try? container.decode(String.self) {
            let formatter = ISO8601DateFormatter()
            if let date = formatter.date(from: dateString) {
                self = .date(date)
                return
            }
        }
        
        throw DecodingError.dataCorruptedError(
            in: container,
            debugDescription: "Cannot decode form value type"
        )
    }
}

/// Option for selection-based elements
struct FormElementOption: Decodable {
    let id: String
    let label: String
}

/// Condition for element visibility
struct VisibilityCondition: Decodable {
    let field: String
    let equals: FormValueType
}

/// Validation rule for an element
struct ValidationRule: Decodable {
    let regex: String?
    let rule: String?
    let value: FormValueType?
    let errorMessage: String
    let minValue: Double?
    let maxValue: Double?
    let matchField: String?
    let checksum: String?
}

/// Form field formatter
struct FormatterDefinition: Decodable {
    let type: String
    let locale: String?
    let currency: String?
}

/// Date constraint (for date pickers)
enum DateConstraint: Decodable {
    case fixed(String)
    case relative(RelativeDateConstraint)
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        
        if let stringValue = try? container.decode(String.self) {
            self = .fixed(stringValue)
            return
        }
        
        if let relativeConstraint = try? container.decode(RelativeDateConstraint.self) {
            self = .relative(relativeConstraint)
            return
        }
        
        throw DecodingError.dataCorruptedError(
            in: container,
            debugDescription: "Cannot decode date constraint"
        )
    }
}

/// Relative date constraint
struct RelativeDateConstraint: Decodable {
    let dependsOn: String
    let offset: String
}

// MARK: - Form View Models

/// Main view model for the form
class DynamicFormViewModel: ObservableObject {
    @Published var formSpecification: FormSpecification?
    @Published var formValues: [String: Any] = [:]
    @Published var formErrors: [String: String] = [:]
    @Published var currentSectionIndex: Int = 0
    @Published var isLoading: Bool = false
    
    private var formLoader = FormLoader()
    private var cancellables: Set<AnyCancellable> = []
    
    init() {}
    
    /// Load form specification from a JSON file
    func loadForm(from jsonUrl: URL) {
        isLoading = true
        
        formLoader.load(from: jsonUrl)
            .receive(on: DispatchQueue.main)
            .sink(
                receiveCompletion: { [weak self] completion in
                    self?.isLoading = false
                    
                    if case .failure(let error) = completion {
                        print("Error loading form: \(error)")
                    }
                },
                receiveValue: { [weak self] specification in
                    self?.formSpecification = specification
                    self?.initializeDefaultValues(for: specification)
                }
            )
            .store(in: &cancellables)
    }
    
    /// Initialize default values from the form specification
    private func initializeDefaultValues(for specification: FormSpecification) {
        for section in specification.sections {
            for element in section.elements {
                if let defaultValue = element.defaultValue {
                    switch defaultValue {
                    case .string(let value):
                        formValues[element.id] = value
                    case .integer(let value):
                        formValues[element.id] = value
                    case .double(let value):
                        formValues[element.id] = value
                    case .boolean(let value):
                        formValues[element.id] = value
                    case .date(let value):
                        formValues[element.id] = value
                    }
                }
            }
        }
    }
    
    /// Update a form value
    func updateValue(_ value: Any, for elementId: String) {
        formValues[elementId] = value
        validateField(elementId)
        
        // Update dependent fields visibility if needed
        updateDependentFields(for: elementId)
    }
    
    /// Navigate to the next section
    func nextSection() {
        guard let specification = formSpecification else { return }
        
        let currentSection = specification.sections[currentSectionIndex]
        if validateSection(currentSection) {
            if currentSectionIndex < specification.sections.count - 1 {
                currentSectionIndex += 1
            } else {
                // Navigate to review screen
                // This would typically trigger a navigation action
            }
        }
    }
    
    /// Navigate to the previous section
    func previousSection() {
        if currentSectionIndex > 0 {
            currentSectionIndex -= 1
        }
    }
    
    /// Submit the form
    func submitForm() {
        guard let specification = formSpecification else { return }
        
        // Validate all sections before submitting
        var isValid = true
        for section in specification.sections {
            if !validateSection(section) {
                isValid = false
            }
        }
        
        if isValid {
            // Here you would implement the API call based on the action definition
            print("Submitting form to: \(specification.actions.submit.endpoint)")
            print("Form values: \(formValues)")
        }
    }
    
    /// Save form as draft
    func saveFormDraft() {
        guard let specification = formSpecification else { return }
        
        // Here you would implement the API call to save a draft
        print("Saving draft to: \(specification.actions.save.endpoint)")
        print("Form values: \(formValues)")
    }
    
    /// Cancel the form
    func cancelForm(completion: @escaping (Bool) -> Void) {
        guard let specification = formSpecification else {
            completion(true)
            return
        }
        
        if specification.actions.cancel.confirmationRequired {
            // The view would show a confirmation alert
            // For now, we just simulate it
            print("Cancel confirmation: \(specification.actions.cancel.confirmationMessage ?? "Are you sure?")")
            
            // In a real app, this would wait for user confirmation
            // For this example, we just proceed
            completion(true)
        } else {
            completion(true)
        }
    }
    
    /// Validate a specific field
    private func validateField(_ elementId: String) -> Bool {
        guard let specification = formSpecification else { return true }
        
        // Find the element in all sections
        for section in specification.sections {
            if let element = section.elements.first(where: { $0.id == elementId }),
               let validation = element.validation {
                
                // Get the current value
                let value = formValues[elementId]
                
                // Clear any existing error
                formErrors.removeValue(forKey: elementId)
                
                // Perform validation based on the rule type
                if let regex = validation.regex, let stringValue = value as? String {
                    let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
                    if !predicate.evaluate(with: stringValue) {
                        formErrors[elementId] = validation.errorMessage
                        return false
                    }
                }
                
                if let rule = validation.rule {
                    switch rule {
                    case "isTrue":
                        if let boolValue = value as? Bool, !boolValue {
                            formErrors[elementId] = validation.errorMessage
                            return false
                        }
                        
                    case "hasMinimumBalance":
                        if let requiredBalance = validation.value, case .double(let minBalance) = requiredBalance {
                            // This would check against an account balance
                            // For this example, we assume it passes
                        }
                        
                    default:
                        break
                    }
                }
                
                // Match field validation
                if let matchField = validation.matchField {
                    let matchValue = formValues[matchField]
                    if value != matchValue {
                        formErrors[elementId] = validation.errorMessage
                        return false
                    }
                }
                
                // Min/max value validation
                if let numericValue = value as? Double {
                    if let minValue = validation.minValue, numericValue < minValue {
                        formErrors[elementId] = validation.errorMessage
                        return false
                    }
                    
                    if let maxValue = validation.maxValue, numericValue > maxValue {
                        formErrors[elementId] = validation.errorMessage
                        return false
                    }
                }
                
                // Checksum validation (e.g. for routing numbers)
                if let checksum = validation.checksum, checksum == "abaRoutingChecksum",
                   let routingString = value as? String, routingString.count == 9 {
                    if !validateABARoutingNumber(routingString) {
                        formErrors[elementId] = validation.errorMessage
                        return false
                    }
                }
                
                return true
            }
        }
        
        return true
    }
    
    /// Validate an entire section
    private func validateSection(_ section: FormSection) -> Bool {
        var isValid = true
        
        for element in section.elements {
            // Only validate fields that are currently visible and required
            if isElementVisible(element) && element.required {
                if formValues[element.id] == nil {
                    formErrors[element.id] = "This field is required"
                    isValid = false
                } else if !validateField(element.id) {
                    isValid = false
                }
            }
        }
        
        return isValid
    }
    
    /// Check if an element should be visible based on current form values
    private func isElementVisible(_ element: FormElement) -> Bool {
        if let visibilityCondition = element.visibleWhen {
            let dependentFieldId = visibilityCondition.field
            let dependentValue = formValues[dependentFieldId]
            
            switch visibilityCondition.equals {
            case .string(let targetValue):
                return dependentValue as? String == targetValue
            case .integer(let targetValue):
                return dependentValue as? Int == targetValue
            case .double(let targetValue):
                return dependentValue as? Double == targetValue
            case .boolean(let targetValue):
                return dependentValue as? Bool == targetValue
            case .date(let targetValue):
                return dependentValue as? Date == targetValue
            }
        }
        
        return true
    }
    
    /// Update dependent fields when a field's value changes
    private func updateDependentFields(for elementId: String) {
        guard let specification = formSpecification else { return }
        
        for section in specification.sections {
            for element in section.elements {
                if element.id == elementId, let dependentFields = element.dependentFields {
                    // Get the current value for the element
                    if let value = formValues[elementId] {
                        // Convert value to string for dictionary key lookup
                        let valueKey: String
                        
                        if let boolValue = value as? Bool {
                            valueKey = String(boolValue)
                        } else {
                            valueKey = String(describing: value)
                        }
                        
                        // Process any dependent fields for this value
                        if let fieldsToProcess = dependentFields[valueKey] {
                            // This indicates fields that should be shown for this value
                            // You may need to handle this differently based on your UI implementation
                            print("Fields to process for \(elementId) = \(value): \(fieldsToProcess)")
                        }
                    }
                }
            }
        }
    }
    
    /// Validate ABA routing number using the checksum algorithm
    private func validateABARoutingNumber(_ routingNumber: String) -> Bool {
        guard routingNumber.count == 9, let _ = Int(routingNumber) else {
            return false
        }
        
        // ABA routing number checksum algorithm
        let digits = routingNumber.compactMap { Int(String($0)) }
        let weightedSum = digits[0] * 3 + digits[1] * 7 + digits[2] * 1 +
                          digits[3] * 3 + digits[4] * 7 + digits[5] * 1 +
                          digits[6] * 3 + digits[7] * 7 + digits[8] * 1
        
        return weightedSum % 10 == 0
    }
}

// MARK: - Form Loader

/// Responsible for loading form specifications from JSON
class FormLoader {
    func load(from url: URL) -> AnyPublisher<FormSpecification, Error> {
        return URLSession.shared.dataTaskPublisher(for: url)
            .map { $0.data }
            .decode(type: FormSpecification.self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
    
    func load(from data: Data) -> AnyPublisher<FormSpecification, Error> {
        return Just(data)
            .decode(type: FormSpecification.self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
}

// MARK: - Form View Components

/// DynamicFormView - Main container for the form
struct DynamicFormView: View {
    @ObservedObject var viewModel: DynamicFormViewModel
    @State private var showCancelConfirmation = false
    
    var body: some View {
        NavigationView {
            VStack {
                if viewModel.isLoading {
                    ProgressView("Loading form...")
                } else if let specification = viewModel.formSpecification {
                    VStack {
                        // Form progress indicator
                        ProgressView(value: Double(viewModel.currentSectionIndex + 1),
                                     total: Double(specification.sections.count))
                            .padding()
                        
                        // Current section
                        if viewModel.currentSectionIndex < specification.sections.count {
                            let section = specification.sections[viewModel.currentSectionIndex]
                            
                            ScrollView {
                                VStack(alignment: .leading, spacing: 20) {
                                    Text(section.title)
                                        .font(.headline)
                                        .padding(.bottom, 5)
                                    
                                    // Render elements for the current section
                                    ForEach(section.elements, id: \.id) { element in
                                        if viewModel.isElementVisible(element) {
                                            FormElementView(
                                                element: element,
                                                formValues: viewModel.formValues,
                                                formErrors: viewModel.formErrors,
                                                updateValue: { value in
                                                    viewModel.updateValue(value, for: element.id)
                                                }
                                            )
                                        }
                                    }
                                }
                                .padding()
                            }
                            
                            // Navigation buttons
                            HStack {
                                if viewModel.currentSectionIndex > 0 {
                                    Button("Previous") {
                                        viewModel.previousSection()
                                    }
                                    .padding()
                                }
                                
                                Spacer()
                                
                                if viewModel.currentSectionIndex < specification.sections.count - 1 {
                                    Button("Next") {
                                        viewModel.nextSection()
                                    }
                                    .padding()
                                } else {
                                    Button("Review") {
                                        // Navigate to review screen
                                        // This would typically be handled by your navigation system
                                    }
                                    .padding()
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                } else {
                    Text("Form could not be loaded")
                        .foregroundColor(.red)
                }
            }
            .navigationTitle(viewModel.formSpecification?.formName ?? "Form")
            .navigationBarItems(
                trailing: Button("Cancel") {
                    if viewModel.formSpecification?.actions.cancel.confirmationRequired == true {
                        showCancelConfirmation = true
                    } else {
                        viewModel.cancelForm { _ in
                            // Handle navigation back
                        }
                    }
                }
            )
            .alert(isPresented: $showCancelConfirmation) {
                Alert(
                    title: Text("Cancel Form"),
                    message: Text(viewModel.formSpecification?.actions.cancel.confirmationMessage ?? "Are you sure you want to cancel?"),
                    primaryButton: .destructive(Text("Yes")) {
                        viewModel.cancelForm { _ in
                            // Handle navigation back
                        }
                    },
                    secondaryButton: .cancel()
                )
            }
        }
    }
}

/// FormElementView - Renders a single form element based on its type
struct FormElementView: View {
    let element: FormElement
    let formValues: [String: Any]
    let formErrors: [String: String]
    let updateValue: (Any) -> Void
    
    var body: some View {
        VStack(alignment: .leading) {
            // Element label with required indicator
            HStack {
                Text(element.label)
                    .font(.subheadline)
                    .foregroundColor(.primary)
                
                if element.required {
                    Text("*")
                        .foregroundColor(.red)
                }
            }
            
            // Element input based on type
            switch element.type {
            case "textField":
                TextFieldElementView(
                    element: element,
                    value: formValueAsString(),
                    updateValue: updateValue
                )
                
            case "datePicker":
                DatePickerElementView(
                    element: element,
                    value: formValueAsDate() ?? Date(),
                    updateValue: updateValue
                )
                
            case "picker":
                PickerElementView(
                    element: element,
                    value: formValueAsString(),
                    updateValue: updateValue
                )
                
            case "segmentedControl":
                SegmentedControlView(
                    element: element,
                    value: formValueAsString(),
                    updateValue: updateValue
                )
                
            case "toggle":
                ToggleElementView(
                    element: element,
                    value: formValueAsBool(),
                    updateValue: updateValue
                )
                
            case "checkbox":
                CheckboxElementView(
                    element: element,
                    value: formValueAsBool(),
                    updateValue: updateValue
                )
                
            default:
                Text("Unsupported element type: \(element.type)")
                    .foregroundColor(.red)
            }
            
            // Error message if any
            if let errorMessage = formErrors[element.id] {
                Text(errorMessage)
                    .font(.caption)
                    .foregroundColor(.red)
            }
        }
    }
    
    // Helper methods to convert form values to appropriate types
    private func formValueAsString() -> String {
        if let value = formValues[element.id] as? String {
            return value
        }
        return ""
    }
    
    private func formValueAsInt() -> Int {
        if let value = formValues[element.id] as? Int {
            return value
        }
        return 0
    }
    
    private func formValueAsDouble() -> Double {
        if let value = formValues[element.id] as? Double {
            return value
        }
        return 0.0
    }
    
    private func formValueAsBool() -> Bool {
        if let value = formValues[element.id] as? Bool {
            return value
        }
        return false
    }
    
    private func formValueAsDate() -> Date? {
        return formValues[element.id] as? Date
    }
}

// MARK: - Element-Specific Views

/// Text Field Element View
struct TextFieldElementView: View {
    let element: FormElement
    @State var value: String
    let updateValue: (Any) -> Void
    
    var body: some View {
        VStack {
            if element.multiline == true {
                TextEditor(text: $value)
                    .onChange(of: value) { newValue in
                        updateValue(newValue)
                    }
                    .frame(height: 100)
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color.gray, lineWidth: 1)
                    )
            } else {
                TextField("Enter \(element.label.lowercased())", text: $value)
                    .onChange(of: value) { newValue in
                        updateValue(newValue)
                    }
                    .keyboardType(keyboardType())
                    .textContentType(textContentType())
                    .autocapitalization(autocapitalizationType())
                    .disableAutocorrection(element.textContentType == "emailAddress")
                    .if(element.securityType == "sensitive") { view in
                        view.privacySensitive()
                    }
                    .if(element.maxLength != nil) { view in
                        view.onReceive(Just(value)) { _ in
                            if let maxLength = element.maxLength, value.count > maxLength {
                                value = String(value.prefix(maxLength))
                            }
                        }
                    }
                    .padding()
                    .overlay(
                        RoundedRectangle(cornerRadius: 5)
                            .stroke(Color.gray, lineWidth: 1)
                    )
            }
        }
    }
    
    private func keyboardType() -> UIKeyboardType {
        switch element.keyboardType {
        case "emailAddress":
            return .emailAddress
        case "numberPad":
            return .numberPad
        case "decimalPad":
            return .decimalPad
        case "phonePad":
            return .phonePad
        default:
            return .default
        }
    }
    
    private func textContentType() -> UITextContentType? {
        switch element.textContentType {
        case "emailAddress":
            return .emailAddress
        case "name":
            return .name
        case "telephoneNumber":
            return .telephoneNumber
        default:
            return nil
        }
    }
    
    private func autocapitalizationType() -> UITextAutocapitalizationType {
        switch element.autocapitalizationType {
        case "words":
            return .words
        case "sentences":
            return .sentences
        case "allCharacters":
            return .allCharacters
        case "none":
            return .none
        default:
            return .sentences
        }
    }
}

/// Date Picker Element View
struct DatePickerElementView: View {
    let element: FormElement
    @State var value: Date
    let updateValue: (Any) -> Void
    
    var body: some View {
        DatePicker(
            "",
            selection: $value,
            in: dateRange(),
            displayedComponents: .date
        )
        .onChange(of: value) { newValue in
            updateValue(newValue)
        }
        .padding()
        .overlay(
            RoundedRectangle(cornerRadius: 5)
                .stroke(Color.gray, lineWidth: 1)
        )
    }
    
    private func dateRange() -> ClosedRange<Date> {
        let calendar = Calendar.current
        
        let minDate: Date
        if let minConstraint = element.minDate {
            switch minConstraint {
            case .fixed(let dateString):
                if dateString == "currentDate" {
                    minDate = Date()
                } else if dateString == "currentDatePlus180Days" {
                    minDate = calendar.date(byAdding: .day, value: 180, to: Date()) ?? Date()
                } else {
                    // Default to current date if parsing fails
                    minDate = Date()
                }
            case .relative(let relativeConstraint):
                // This would need to access the dependent field's date
                // For simplicity, we'll use current date
                minDate = Date()
            }
        } else {
            minDate = calendar.date(byAdding: .year, value: -10, to: Date()) ?? Date()
        }
        
        let maxDate: Date
        if let maxConstraint = element.maxDate {
            switch maxConstraint {
            case .fixed(let dateString):
                if dateString == "currentDatePlus180Days" {
                    maxDate = calendar.date(byAdding: .day, value: 180, to: Date()) ?? Date()
                } else if dateString == "currentDatePlus5Years" {
                    maxDate = calendar.date(byAdding: .year, value: 5, to: Date()) ?? Date()
                } else {
                    // Default to far future if parsing fails
                    maxDate = calendar.date(byAdding: .year, value: 10, to: Date()) ?? Date()
                }
            case .relative(let relativeConstraint):
                // This would need to access the dependent field's date
                // For simplicity, we'll use far future
                maxDate = calendar.date(byAdding: .year, value: 10, to: Date()) ?? Date()
            }
        } else {
            maxDate = calendar.date(byAdding: .year, value: 10, to: Date()) ?? Date()
        }
        
        return minDate...maxDate
    }
}

/// Picker Element View
struct PickerElementView: View {
    let element: FormElement
    @State var value: String
    let updateValue: (Any) -> Void
    
    var body: some View {
        if let options = element.options {
            Picker(selection: $value) {
                ForEach(options, id: \.id) { option in
                    Text(option.label)
                        .tag(option.id)
                }
            } label: {
                EmptyView()
            }
            .onChange(of: value) { newValue in
                updateValue(newValue)
            }
            .pickerStyle(MenuPickerStyle())
            .padding()
            .overlay(
                RoundedRectangle(cornerRadius: 5)
                    .stroke(Color.gray, lineWidth: 1)
            )
        } else if let dataSource = element.dataSource {
            // For data sources like "userAccounts" or "savedRecipients"
            // In a real app, you would fetch this data
            Text("Data from \(dataSource)")
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 5)
                        .stroke(Color.gray, lineWidth: 1)
                )
        }
    }
}

/// Segmented Control View
struct SegmentedControlView: View {
    let element: FormElement
    @State var value: String
    let updateValue: (Any) -> Void
    
    var body: some View {
        if let options = element.options {
            Picker("", selection: $value) {
                ForEach(options, id: \.id) { option in
                    Text(option.label)
                        .tag(option.id)
                }
            }
            .onChange(of: value) { newValue in
                updateValue(newValue)
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding(.vertical)
*/
